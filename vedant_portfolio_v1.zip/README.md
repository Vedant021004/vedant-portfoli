Vedant Kapil — Portfolio (Vite + React)
=======================================

How to run:
1. npm install
2. npm run dev
3. Open http://localhost:5173

Notes:
- Replace the profile image at src/assets/profile.png with your preferred photo.
- This project includes framer-motion and lottie-react (if you choose to add Lottie files).