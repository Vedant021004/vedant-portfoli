/* App.jsx - Vedant Kapil Portfolio (Vite/React)
   Single-file app. Keep assets in /public or src/assets as needed.
*/
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import AppRoutes from './routes/AppRoutes';

export default function App(){ 
  return (
    <Router>
      <AppRoutes />
    </Router>
  );
}