import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import AnimatedBackground from '../ui/AnimatedBackground';
import Nav from '../ui/Nav';
import PageWrapper from '../ui/PageWrapper';
import Home from '../pages/Home';
import About from '../pages/About';
import Skills from '../pages/Skills';
import Projects from '../pages/Projects';
import ProgressPage from '../pages/ProgressPage';
import Contact from '../pages/Contact';

export default function AppRoutes(){
  const location = useLocation();
  return (
    <>
      <AnimatedBackground />
      <Nav />
      <AnimatePresence mode="wait" initial={false}>
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<PageWrapper><Home/></PageWrapper>} />
          <Route path="/about" element={<PageWrapper><About/></PageWrapper>} />
          <Route path="/skills" element={<PageWrapper><Skills/></PageWrapper>} />
          <Route path="/projects" element={<PageWrapper><Projects/></PageWrapper>} />
          <Route path="/progress" element={<PageWrapper><ProgressPage/></PageWrapper>} />
          <Route path="/contact" element={<PageWrapper><Contact/></PageWrapper>} />
        </Routes>
      </AnimatePresence>
    </>
  );
}