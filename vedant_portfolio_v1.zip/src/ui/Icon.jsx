import React from 'react';

export default function Icon({ name, size = 20 }){
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch(name){
    case 'html': return (<svg {...common}><path d="M3 4l1.5 16L12 22l7.5-2L21 4" stroke="#FF6B6B"/><path d="M7.5 8h9M7.5 12h9" stroke="#FFD486"/></svg>);
    case 'js': return (<svg {...common}><rect x="2" y="2" width="20" height="20" rx="3" stroke="#F0DB4F" fill="rgba(240,219,79,0.08)"/><path d="M7 7h10v10s-2 2-5 2-5-2-5-2V7z" stroke="#F7DF1E"/></svg>);
    case 'react': return (<svg {...common}><g stroke="#61DAFB"><ellipse cx="12" cy="12" rx="7" ry="3.5"/><ellipse cx="12" cy="12" rx="3.5" ry="7" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="3.5" ry="7" transform="rotate(-60 12 12)"/><circle cx="12" cy="12" r="1.6" fill="#61DAFB" stroke="none"/></g></svg>);
    case 'cpp': return (<svg {...common}><path d="M3 7h6v10H3z" stroke="#9AD3FF"/><path d="M9 7l6 5-6 5V7z" stroke="#7FB3FF"/><text x="18" y="13" fontSize="9" fontWeight="700" fill="#B0D4FF">C++</text></svg>);
    case 'python': return (<svg {...common}><path d="M3 8c2-3 8-4 8-4h2c0 0 6 1 8 4v4c-2 3-8 4-8 4h-2c0 0-6-1-8-4V8z" stroke="#FFE873" fill="rgba(255,232,115,0.06)"/><circle cx="7" cy="9" r="0.7" fill="#FFE873"/><circle cx="17" cy="15" r="0.7" fill="#FFE873"/></svg>);
    case 'figma': return (<svg {...common}><circle cx="7" cy="7" r="2.6" fill="#FF7262"/><rect x="9.4" y="4.4" width="2.6" height="5.2" rx="1.3" fill="#A259FF"/><rect x="12" y="4.4" width="2.6" height="5.2" rx="1.3" fill="#F24E1E"/><rect x="9.4" y="9.6" width="5.2" height="2.6" rx="1.3" fill="#FF7262"/></svg>);
    default: return (<svg {...common}><circle cx="12" cy="12" r="10" stroke="#fff"/></svg>);
  }
}