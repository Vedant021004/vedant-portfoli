import React from 'react';
import { Link } from 'react-router-dom';

const styles = {
  container: { maxWidth: 1200, margin: '0 auto', padding: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  navLink: { color: 'rgba(255,255,255,0.85)', textDecoration: 'none', fontWeight: 700, padding: '8px 12px', borderRadius: 10 },
  primaryBtn: { background: 'linear-gradient(90deg,#ff616b,#a32b2b)', color: '#080606', padding: '8px 12px', borderRadius: 10, fontWeight: 800, textDecoration: 'none' }
};

export default function Nav(){
  return (
    <div style={styles.container}>
      <div style={{ fontWeight: 900 }}>VEDANT KAPIL</div>
      <div style={{ display:'flex', gap:12 }}>
        <Link to="/" style={styles.navLink}>Home</Link>
        <Link to="/about" style={styles.navLink}>About</Link>
        <Link to="/skills" style={styles.navLink}>Skills</Link>
        <Link to="/projects" style={styles.navLink}>Projects</Link>
        <Link to="/progress" style={styles.navLink}>Progress</Link>
        <Link to="/contact" style={styles.primaryBtn}>Contact</Link>
      </div>
    </div>
  );
}