import React from 'react';
import { motion } from 'framer-motion';

export default function ProgressRing({ size=120, stroke=12, percent=75, label='' }){
  const normalizedRadius = (size - stroke) / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  return (
    <div style={{ display:'inline-block', textAlign:'center', width:size }}>
      <svg height={size} width={size} style={{ display:'block', margin:'0 auto' }}>
        <defs>
          <linearGradient id={`g-${label}`} x1="0%" x2="100%">
            <stop offset="0%" stopColor="#ff616b" />
            <stop offset="100%" stopColor="#a32b2b" />
          </linearGradient>
        </defs>
        <circle stroke="rgba(255,255,255,0.06)" fill="transparent" strokeWidth={stroke} r={normalizedRadius} cx={size/2} cy={size/2} />
        <motion.circle
          stroke={`url(#g-${label})`}
          fill="transparent"
          strokeWidth={stroke}
          r={normalizedRadius}
          cx={size/2}
          cy={size/2}
          strokeDasharray={`${circumference} ${circumference}`}
          strokeLinecap="round"
          transform={`rotate(-90 ${size/2} ${size/2})`}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference - (percent/100) * circumference }}
          transition={{ duration: 1.0, ease: 'easeOut' }}
        />
        <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fontWeight={800} style={{ fontSize: 18, fill:'#fff' }}>{percent}%</text>
      </svg>
      <div style={{ marginTop:8, color:'rgba(255,255,255,0.85)', fontWeight:700 }}>{label}</div>
    </div>
  );
}