import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ProgressRing from './ProgressRing';
import Icon from './Icon';

export default function SkillDetailModal({ skill, onClose }){
  const overlayRef = useRef(null);
  useEffect(()=>{
    const mapping = { 'HTML/CSS': 15, 'JavaScript': 45, 'React': 200, 'C++': 300, 'Python': 70, 'Design (Figma)': 320 };
    const delta = mapping[skill.name] || 0;
    if(window.__setBackgroundHue) window.__setBackgroundHue(delta);

    function onKey(e){ if(e.key === 'Escape') onClose(); }
    document.addEventListener('keydown', onKey);

    const prevActive = document.activeElement;
    const focusEl = overlayRef.current && overlayRef.current.querySelector('button, a, input, textarea');
    if(focusEl) focusEl.focus();

    return ()=>{ document.removeEventListener('keydown', onKey); if(window.__setBackgroundHue) window.__setBackgroundHue(0); if(prevActive) prevActive.focus(); };
  },[skill, onClose]);

  const tools = skill.tools || ['VS Code','Git','Browser DevTools'];
  const projects = skill.projects || [];

  return (
    <AnimatePresence>
      <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} style={{ position:'fixed', inset:0, display:'flex', alignItems:'center', justifyContent:'center', zIndex:60 }}>
        <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} transition={{duration:0.28}} style={{ position:'fixed', inset:0, backdropFilter:'blur(10px)', background:'rgba(0,0,0,0.46)', zIndex:61 }} />
        <motion.div ref={overlayRef} initial={{scale:0.98, y:20, opacity:0}} animate={{scale:1, y:0, opacity:1}} exit={{scale:0.98, y:10, opacity:0}} transition={{duration:0.32}} style={{ width:'min(880px,92%)', borderRadius:16, padding:22, background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', boxShadow:'0 40px 120px rgba(0,0,0,0.7)', backdropFilter:'blur(6px)', position:'relative', zIndex:62 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:20 }}>
            <div>
              <div style={{ color:'rgba(255,255,255,0.75)', fontWeight:800, letterSpacing:1, display:'flex', alignItems:'center', gap:10 }}>
                <Icon name={skill.icon} size={22} />
                <span>{skill.name}</span>
              </div>
              <h3 style={{ margin:'6px 0 0' }}>{skill.percent}% mastery</h3>
              <p style={{ marginTop:8, color:'rgba(255,255,255,0.78)' }}>{skill.description || 'Experienced in building real-world interfaces and performant UI.'}</p>
            </div>
            <div style={{ display:'flex', gap:12, alignItems:'center' }}>
              <ProgressRing percent={skill.percent} label={skill.name} />
            </div>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginTop:18 }}>
            <div style={{ padding:12, borderRadius:12, background:'rgba(255,255,255,0.02)' }}>
              <div style={{ fontWeight:800, marginBottom:8, display:'flex', alignItems:'center', gap:8 }}><svg width="16" height="16" viewBox="0 0 24 24"><path d="M12 2v6" stroke="#fff" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg> Tools & Tech</div>
              <ul style={{ margin:0, paddingLeft:18 }}>
                {tools.map(t=> <li key={t} style={{ color:'rgba(255,255,255,0.85)' }}>{t}</li>)}
              </ul>
            </div>
            <div style={{ padding:12, borderRadius:12, background:'rgba(255,255,255,0.02)' }}>
              <div style={{ fontWeight:800, marginBottom:8, display:'flex', alignItems:'center', gap:8 }}><svg width="16" height="16" viewBox="0 0 24 24"><path d="M3 12h18" stroke="#fff" strokeWidth="1.2" strokeLinecap="round"/></svg> Projects using this skill</div>
              <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                {projects.length ? projects.map(p=> (
                  <div key={p.title} style={{ padding:8, borderRadius:8, background:'linear-gradient(90deg, rgba(255,255,255,0.02), rgba(0,0,0,0.12))' }}>
                    <div style={{ fontWeight:800 }}>{p.title}</div>
                    <div style={{ fontSize:13, color:'rgba(255,255,255,0.7)' }}>{p.desc}</div>
                  </div>
                )) : <div style={{ color:'rgba(255,255,255,0.75)' }}>No public projects listed.</div>}
              </div>
            </div>
          </div>
          <div style={{ display:'flex', justifyContent:'flex-end', marginTop:16 }}>
            <button onClick={onClose} style={{ padding:'10px 14px', borderRadius:10, background:'transparent', border:'1px solid rgba(255,255,255,0.06)', color:'#fff', fontWeight:800 }}>Close</button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}