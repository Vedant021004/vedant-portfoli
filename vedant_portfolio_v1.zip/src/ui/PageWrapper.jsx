import React from 'react';
import { motion } from 'framer-motion';

export default function PageWrapper({children}){
  return (
    <motion.div initial={{opacity:0, filter:'blur(8px)'}} animate={{opacity:1, filter:'blur(0px)'}} exit={{opacity:0, filter:'blur(8px)'}} transition={{duration:0.6}} style={{ position:'relative', zIndex:20 }}>
      {children}
    </motion.div>
  );
}