import React, { useEffect } from 'react';

export default function AnimatedBackground(){
  useEffect(()=>{
    const canvas = document.createElement('canvas');
    canvas.style.position='fixed'; canvas.style.inset='0'; canvas.style.zIndex='0'; canvas.style.pointerEvents='none';
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    let dpr = Math.max(window.devicePixelRatio||1,1);
    let w = canvas.width = Math.round(window.innerWidth*dpr);
    let h = canvas.height = Math.round(window.innerHeight*dpr);
    canvas.style.width = window.innerWidth+'px'; canvas.style.height = window.innerHeight+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);

    const blobs = [
      { x:w*0.12, y:h*0.18, r:Math.max(w,h)*0.42, hue:345, targetHue:345, sat:88, light:60, vx:0.02, vy:0.015 },
      { x:w*0.86, y:h*0.22, r:Math.max(w,h)*0.36, hue:280, targetHue:280, sat:80, light:54, vx:-0.018, vy:0.02 },
      { x:w*0.32, y:h*0.78, r:Math.max(w,h)*0.5, hue:28, targetHue:28, sat:82, light:56, vx:0.015, vy:-0.02 }
    ];

    window.__setBackgroundHue = (deltaHue)=>{ blobs.forEach((b,i)=> b.targetHue = (b.hue + deltaHue + i*8)%360); };

    let t=0;
    function lerp(a,b,n){return a + (b-a)*n}
    function resize(){ dpr = Math.max(window.devicePixelRatio||1,1); w = canvas.width = Math.round(window.innerWidth*dpr); h = canvas.height = Math.round(window.innerHeight*dpr); canvas.style.width = window.innerWidth+'px'; canvas.style.height = window.innerHeight+'px'; ctx.setTransform(dpr,0,0,dpr,0,0); }

    function draw(){
      t += 0.012;
      ctx.clearRect(0,0,w,h);
      ctx.globalCompositeOperation = 'screen';
      blobs.forEach((b,i)=>{
        b.x += Math.sin(t*(0.6+i*0.12))*(b.vx*60);
        b.y += Math.cos(t*(0.4+i*0.08))*(b.vy*60);
        b.hue = lerp(b.hue, b.targetHue, 0.025);
        const grad = ctx.createRadialGradient(b.x,b.y,b.r*0.05,b.x,b.y,b.r);
        grad.addColorStop(0, `hsla(${b.hue}, ${b.sat}%, ${b.light}%, 0.98)`);
        grad.addColorStop(0.45, `hsla(${(b.hue-30+360)%360}, ${b.sat-18}%, ${b.light-10}%, 0.42)`);
        grad.addColorStop(1, `hsla(${(b.hue-60+360)%360}, ${b.sat-36}%, ${b.light-30}%, 0.06)`);
        ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(b.x,b.y,b.r,0,Math.PI*2); ctx.fill();
      });
      ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle='rgba(0,0,0,0.16)'; ctx.fillRect(0,0,w,h);
      requestAnimationFrame(draw);
    }
    draw(); window.addEventListener('resize', resize);
    return ()=>{ window.removeEventListener('resize', resize); canvas.remove(); delete window.__setBackgroundHue; };
  },[]);
  return null;
}