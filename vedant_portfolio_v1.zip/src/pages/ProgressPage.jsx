import React from 'react';
import ProgressRing from '../ui/ProgressRing';

export default function ProgressPage(){
  const tasks = [
    { id:1, title:'AI UI Research', percent:42, desc:'Experimenting with generative UI flows and models to assist design.' },
    { id:2, title:'Three.js Product Stage', percent:65, desc:'Polishing performance and interactions.' },
    { id:3, title:'Micro-interaction Library', percent:78, desc:'Building components and documentation.' }
  ];
  return (
    <section style={{ padding:'60px 20px' }}>
      <div style={{ maxWidth:1200, margin:'0 auto' }}>
        <h2>Current Progress</h2>
        <p style={{ color:'rgba(255,255,255,0.75)' }}>What I am actively working on — live progress bars to track the workflow.</p>
        <div style={{ display:'grid', gap:16, marginTop:20 }}>
          {tasks.map(t=>(
            <div key={t.id} style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:16, borderRadius:14, display:'flex', alignItems:'center', gap:16 }}>
              <div style={{ width:140 }}><ProgressRing percent={t.percent} label={t.title} /></div>
              <div>
                <h3 style={{ margin:0 }}>{t.title}</h3>
                <p style={{ margin:0, color:'rgba(255,255,255,0.8)' }}>{t.desc}</p>
                <div style={{ marginTop:10, height:8, width:400, background:'rgba(255,255,255,0.06)', borderRadius:8, overflow:'hidden' }}>
                  <div style={{ width:`${t.percent}%`, height:'100%', background:'linear-gradient(90deg,#ff616b,#a32b2b)' }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}