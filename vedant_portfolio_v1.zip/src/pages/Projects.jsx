import React from 'react';
import ProgressRing from '../ui/ProgressRing';
import Icon from '../ui/Icon';

export default function Projects(){
  const projects = [
    { id:1, title:'Cinematic Landing Page', desc:'High-contrast landing with layered gradients, motion, and responsive interactions.', progress:100, tags:['React','CSS','Motion'], icon:'react' },
    { id:2, title:'Interactive Portfolio', desc:'Modular portfolio site with premium animations and accessibility in mind.', progress:92, tags:['React','Framer Motion'], icon:'html' },
    { id:3, title:'3D Product Stage', desc:'Three.js product viewer with interactive camera and performance optimizations.', progress:65, tags:['Three.js','WebGL'], icon:'react' },
    { id:4, title:'UI Micro-interaction Library', desc:'Reusable animation primitives and micro-interactions for product teams.', progress:78, tags:['JS','CSS'], icon:'js' }
  ];
  return (
    <section style={{ padding:'60px 20px' }}>
      <div style={{ maxWidth:1200, margin:'0 auto' }}>
        <h2>Projects</h2>
        <p style={{ color:'rgba(255,255,255,0.75)' }}>Selected projects — each crafted with motion, clarity and performance.</p>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:20, marginTop:20 }}>
          {projects.map(p=>(
            <article key={p.id} style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:16, borderRadius:14 }}>
              <div style={{ display:'flex', alignItems:'center', gap:12 }}><Icon name={p.icon} size={28} /><h3 style={{ margin:0 }}>{p.title}</h3></div>
              <p style={{ margin:0, color:'rgba(255,255,255,0.78)' }}>{p.desc}</p>
              <div style={{ display:'flex', gap:12, alignItems:'center', marginTop:12 }}>
                <ProgressRing percent={p.progress} label={'Progress'} />
                <div>
                  <div style={{ color:'rgba(255,255,255,0.9)', fontWeight:800 }}>{p.progress}%</div>
                  <div style={{ color:'rgba(255,255,255,0.7)', fontSize:13 }}>{p.tags.join(' • ')}</div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}