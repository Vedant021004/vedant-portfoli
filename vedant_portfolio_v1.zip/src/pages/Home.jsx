import React from 'react';
import { Link } from 'react-router-dom';
import profile from '../assets/profile.png';

export default function Home(){
  return (
    <section style={{ minHeight:'80vh', display:'grid', gridTemplateColumns:'1fr 420px', gap:48, alignItems:'center', padding:'80px 20px' }}>
      <div>
        <div style={{ textTransform:'uppercase', letterSpacing:2, color:'rgba(255,255,255,0.65)', fontSize:12 }}>User Experience Portfolio</div>
        <h1 style={{ fontSize:56, margin:'12px 0', lineHeight:1 }}>Design that moves<br/>and feels alive</h1>
        <p style={{ color:'rgba(255,255,255,0.78)', maxWidth:700 }}>I build cinematic, motion-forward interfaces with careful attention to micro-interactions. Currently exploring AI-driven UI and advanced WebGL visuals.</p>
        <div style={{ marginTop:20, display:'flex', gap:12 }}>
          <Link to="/skills" style={{ background: 'linear-gradient(90deg,#ff616b,#a32b2b)', color: '#080606', padding: '10px 14px', borderRadius: 12, fontWeight: 800, textDecoration: 'none' }}>My Skills</Link>
          <a href="#projects" style={{ color:'rgba(255,255,255,0.85)', textDecoration:'none', padding: '8px 12px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)' }}>See Work</a>
        </div>
      </div>

      <div style={{ display:'flex', alignItems:'center', justifyContent:'center' }}>
        <div style={{ width:340, height:340, borderRadius:'50%', padding:10, background:'linear-gradient(180deg, rgba(255,255,255,0.03), rgba(0,0,0,0.06))', boxShadow:'0 30px 90px rgba(0,0,0,0.7)', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <img src={profile} alt="Vedant" style={{ width:300, height:300, borderRadius:'50%', objectFit:'cover', boxShadow:'0 30px 100px rgba(0,0,0,0.6)' }} />
        </div>
      </div>
    </section>
  );
}