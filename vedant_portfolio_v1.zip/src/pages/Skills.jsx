import React, { useState } from 'react';
import ProgressRing from '../ui/ProgressRing';
import Icon from '../ui/Icon';
import SkillDetailModal from '../ui/SkillDetailModal';

export default function Skills(){
  const skills = [
    { name:'HTML/CSS', percent:95, icon:'html', description:'Semantic markup, responsive layouts, modern CSS (Flexbox, Grid), animations.', tools:['VS Code','Chrome DevTools','PostCSS'], projects:[{title:'Portfolio',desc:'Responsive portfolio with animated background.'}] },
    { name:'JavaScript', percent:90, icon:'js', description:'Vanilla JS, DOM, ES6+, async patterns, performant code.', tools:['Node','Webpack','Babel'], projects:[{title:'Motion Library',desc:'Reusable micro-interactions.'}] },
    { name:'React', percent:88, icon:'react', description:'Component architecture, hooks, state management, Framer Motion.', tools:['React Router','Framer Motion','Vite'], projects:[{title:'Interactive SPA',desc:'Multi-page portfolio app.'}] },
    { name:'C++', percent:82, icon:'cpp', description:'Systems programming fundamentals, competitive programming basics.', tools:['g++','VS Code'], projects:[] },
    { name:'Python', percent:75, icon:'python', description:'Scripting, data processing, small automation tasks.', tools:['Jupyter','Requests'], projects:[] },
    { name:'Design (Figma)', percent:85, icon:'figma', description:'Wireframes, prototypes, motion specs and handoff-ready assets.', tools:['Figma'], projects:[{title:'Landing Concepts',desc:'High-fidelity landing prototypes.'}] }
  ];
  const [selected, setSelected] = useState(null);
  function openSkill(s){ setSelected(s); }
  function closeSkill(){ setSelected(null); }
  return (
    <section style={{ padding:'60px 20px' }}>
      <div style={{ maxWidth:1200, margin:'0 auto' }}>
        <h2>Skills Dashboard</h2>
        <p style={{ color:'rgba(255,255,255,0.75)' }}>Click any skill ring to view premium details, tools and associated projects.</p>
        <div style={{ display:'flex', gap:20, flexWrap:'wrap', marginTop:20 }}>
          {skills.map(s=>(
            <button key={s.name} onClick={()=>openSkill(s)} style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:16, borderRadius:14, border:'none', cursor:'pointer', width:200 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <Icon name={s.icon} size={26} />
                <div style={{ textAlign:'left' }}>
                  <div style={{ fontWeight:800 }}>{s.name}</div>
                  <div style={{ color:'rgba(255,255,255,0.75)', fontSize:13 }}>{s.percent}%</div>
                </div>
              </div>
              <div style={{ marginTop:6 }}><ProgressRing percent={s.percent} label={''} /></div>
            </button>
          ))}
        </div>
        <div style={{ marginTop:30, background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:20, borderRadius:14 }}>
          <h3>Skill details</h3>
          <p style={{ color:'rgba(255,255,255,0.8)' }}>Tap a skill to open a focused modal — the background will blur and the canvas hue will shift to match the selected skill for a cinematic feel.</p>
        </div>
      </div>
      {selected && <SkillDetailModal skill={selected} onClose={closeSkill} />}
    </section>
  );
}