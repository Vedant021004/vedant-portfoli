import React from 'react';

export default function Contact(){
  return (
    <section style={{ padding:'60px 20px' }}>
      <div style={{ maxWidth:1200, margin:'0 auto' }}>
        <h2>Contact</h2>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 380px', gap:20 }}>
          <div style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:20, borderRadius:14 }}>
            <p style={{ color:'rgba(255,255,255,0.8)' }}>I'm available for internships, freelance and collaborations. Let's build something world-class.</p>
            <p>Email: <a href="mailto:vedant@example.com" style={{ color:'#ff616b' }}>vedant@example.com</a></p>
            <p>Instagram: <a href="https://instagram.com" style={{ color:'#ff616b' }}>@vedant</a></p>
          </div>
          <div style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:20, borderRadius:14 }}>
            <h3>Send a message</h3>
            <form onSubmit={(e)=>{ e.preventDefault(); alert('This demo does not send mail — replace with API integration.'); }} style={{ display:'grid', gap:8 }}>
              <input placeholder='Your name' style={{ padding:10, borderRadius:8, border:'1px solid rgba(255,255,255,0.06)', background:'transparent', color:'#fff' }} />
              <input placeholder='Email' style={{ padding:10, borderRadius:8, border:'1px solid rgba(255,255,255,0.06)', background:'transparent', color:'#fff' }} />
              <textarea placeholder='Message' rows={5} style={{ padding:10, borderRadius:8, border:'1px solid rgba(255,255,255,0.06)', background:'transparent', color:'#fff' }} />
              <button style={{ background: 'linear-gradient(90deg,#ff616b,#a32b2b)', color: '#080606', padding: '10px 14px', borderRadius: 12, fontWeight: 800, border:'none' }}>Send</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}