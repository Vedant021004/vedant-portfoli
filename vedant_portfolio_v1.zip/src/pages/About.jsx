import React from 'react';

export default function About(){
  return (
    <section style={{ padding:'60px 20px' }}>
      <div style={{ maxWidth:1200, margin:'0 auto' }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24, alignItems:'start' }}>
          <div style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:20, borderRadius:14 }}>
            <h2>About Me</h2>
            <p style={{ color:'rgba(255,255,255,0.85)' }}>I’m Vedant, a frontend and UX-focused developer. I blend motion design, interactive UI, and code to create experiences that feel polished and human. I enjoy exploring photography, motion art and 3D web visualizations.</p>
            <ul style={{ marginTop:12, color:'rgba(255,255,255,0.8)' }}>
              <li>Creative problem solving</li>
              <li>Motion-driven design</li>
              <li>Performance-aware coding</li>
            </ul>
          </div>
          <div style={{ display:'grid', gap:12 }}>
            <div style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:20, borderRadius:14 }}>
              <h3>Currently</h3>
              <p style={{ margin:0, color:'rgba(255,255,255,0.8)' }}>Exploring AI-assisted UI tools, Three.js experiments and building a micro-interaction component library.</p>
            </div>

            <div style={{ background:'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', padding:20, borderRadius:14 }}>
              <h3>Values</h3>
              <p style={{ margin:0, color:'rgba(255,255,255,0.8)' }}>Clarity, empathy and delightful motion. I design with accessibility and performance in mind.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}